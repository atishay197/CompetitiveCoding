import java.applet.*;
import java.awt.*;
import java.awt.event.*;

/*
<applet code = "square" height = 150 width = 500>
</applet>
*/

public class square extends Applet implements Runnable
{
	Thread t = null;
	int l=400;

	public void start()
	{
		t = new Thread(this);
		t.start();
	}

	public void run()
	{
		for(;;)
		{
			for(;l>10;)
			{	
				try
				{
					repaint();
					Thread.sleep(50);
					l -= 5;
				}
				catch(InterruptedException e)
				{
					System.out.println("IE caught");
				}
			}
			for(;l<440;)
			{
				try
				{
					repaint();
					Thread.sleep(50);
					l += 5;
				}
				catch(InterruptedException e)
				{
					System.out.println("IE caught");
				}
			}
		}
	}

	public void paint(Graphics g)
	{
		g.fillRect(l,50,50,50);
	}
	
}